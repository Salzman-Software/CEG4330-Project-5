#include <Arduino.h>
#include <math.h>
#include "esp_camera.h"
#include <WiFi.h>
#include <ArduinoJson.h>

// WiFi Settings
#define SSID "your-ssid-here"
#define PASSWORD "your-password-here"
#define CAMERA_PORT 8000
#define JSON_PORT 8001

// Button and LED Settings
#define BUTTON_PIN 15     // Physical pin 23, button to ground
#define LED_PIN 2         // Onboard LED
#define DEBOUNCE_MS 30
#define PWM_CHANNEL 4     // LEDC channel 0 is used by the camera clock, so don't use it for the LED

// Camera Settings
#define PWDN_GPIO_NUM     -1
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM     21
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       19
#define Y4_GPIO_NUM       18
#define Y3_GPIO_NUM       5
#define Y2_GPIO_NUM       4
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

WiFiServer cameraServer;
WiFiServer jsonServer;
WiFiClient cameraClient;
WiFiClient jsonClient;

JsonDocument json;

// Button state (debounced)
int lastReading = HIGH;
int stableReading = HIGH;
unsigned long lastChangeTime = 0;
int buttonState = 0;               // 1 = pressed, 0 = released
int buttonPresses = 0;
unsigned long buttonPressTime = 0; // millis() of the last press


// LED state
constexpr uint8_t PWM_BITS = 8;
constexpr uint32_t PWM_MAX = (1UL << PWM_BITS) - 1;
bool pwmOn = false;
bool serversStarted = false;
bool cameraInitialized = false;
String incomingLine;
bool discardLine = false;

// Call repeatedly: each attempt has a 10-second deadline without blocking.
void connectToWiFi(const char* ssid, const char* password)
{
  static bool attempting = false;
  static unsigned long attemptStarted = 0;
  if (WiFi.status() == WL_CONNECTED)
  {
    attempting = false;
    return;
  }
  if (attempting && millis() - attemptStarted < 10000UL) return;
  if (attempting) Serial.println("WiFi connection failed; retrying...");
  WiFi.disconnect();
  WiFi.begin(ssid, password);
  attemptStarted = millis();
  attempting = true;
}

void startCameraServer(int port)
{
  // If we're not connected to WiFi, do nothing
  if (WiFi.status() != WL_CONNECTED) return;

  if (!cameraInitialized)
  {
    // Setup the camera settings
    camera_config_t config = {};
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer   = LEDC_TIMER_0;
    config.pin_d0       = Y2_GPIO_NUM;
    config.pin_d1       = Y3_GPIO_NUM;
    config.pin_d2       = Y4_GPIO_NUM;
    config.pin_d3       = Y5_GPIO_NUM;
    config.pin_d4       = Y6_GPIO_NUM;
    config.pin_d5       = Y7_GPIO_NUM;
    config.pin_d6       = Y8_GPIO_NUM;
    config.pin_d7       = Y9_GPIO_NUM;
    config.pin_xclk     = XCLK_GPIO_NUM;
    config.pin_pclk     = PCLK_GPIO_NUM;
    config.pin_vsync    = VSYNC_GPIO_NUM;
    config.pin_href     = HREF_GPIO_NUM;
    config.pin_sccb_sda = SIOD_GPIO_NUM;
    config.pin_sccb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn     = PWDN_GPIO_NUM;
    config.pin_reset    = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;
    // Adjust the size and quality to your liking
    // NOTE: Higher quality and size may result in slow transmissions
    config.frame_size   = FRAMESIZE_QVGA; // Size of the output image: FRAMESIZE_ + QVGA|CIF|VGA|SVGA|XGA|SXGA|UXGA
    config.jpeg_quality = 10;             // Quality of JPEG output. 0-63 lower means higher quality
    config.fb_count     = 1;

    // Initialize the camera with the settings
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK)
    {
      Serial.printf("Camera init failed with error 0x%x\n", err);
      return;
    }

    cameraInitialized = true;
  }

  // Start the server and wait for clients
  cameraServer = WiFiServer(port);
  cameraServer.begin();
  Serial.println("Camera server started on port " + String(port));
}

void startJSONServer(int port)
{
  if (WiFi.status() != WL_CONNECTED) return;
  jsonServer = WiFiServer(port);
  jsonServer.begin();
  Serial.println("JSON server started on port " + String(port));
}

void updateJSON()
{
  json["buttonPresses"] = buttonPresses;
  json["buttonPressTime"] = buttonPressTime;
}

void setup()
{
  // Start the serial monitor
  Serial.begin(9600);
  Serial.setTimeout(10); // Timeout is needed to continue to camera processing quickly

  // Button with internal pull up, LED off
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // Connect to the SSID with PASSWORD
  connectToWiFi(SSID, PASSWORD);

  // Servers start in loop() once WiFi connects.

  // Initialize the JSON
  updateJSON();

  Serial.println("Setup complete!");
}

bool sendJSONToClient(WiFiClient client)
{
  if (!client.connected()) return false;
  String jsonString;
  serializeJson(json, jsonString);
  jsonString += '\n';
  return client.print(jsonString) == jsonString.length();
}

bool sendImageToClient(WiFiClient client)
{
  // Get a pointer to the frame buffer of the camera
  camera_fb_t *fb = esp_camera_fb_get();

  // If the frame buffer is null (we did not get an image!)
  if (!fb)
  {
    Serial.println("Capture failed");
    return true;
  }

  // Send the frame buffer (4-byte length, then the JPEG)
  uint32_t len = fb->len;
  client.write((uint8_t*)&len, sizeof(len));
  client.write(fb->buf, fb->len);

  // Tell the camera that it can reuse this frame buffer now that we've sent it off
  esp_camera_fb_return(fb);

  return false;
}

void handleJSONFromClient(WiFiClient client)
{
  // TCP can split a line across packets. Keep partial lines between loop calls.
  // Bound work and storage so a slow or oversized message cannot stall polling.
  for (int n = 0; n < 256 && client.available(); ++n)
  {
    char c = static_cast<char>(client.read());
    if (c != '\n')
    {
      if (!discardLine && incomingLine.length() < 512) incomingLine += c;
      else discardLine = true;
      continue;
    }
    String receivedData = incomingLine;
    incomingLine = "";
    if (discardLine)
    {
      discardLine = false;
      client.println("error: message too long");
      continue;
    }
    receivedData.trim();
    if (receivedData.isEmpty()) continue;
    Serial.println("Received: " + receivedData);
    // A raw test line provides the assignment's bidirectional TCP test.
    if (receivedData == "test")
    {
      client.println("test");
      continue;
    }
    JsonDocument rx;
    DeserializationError error = deserializeJson(rx, receivedData);
    if (error)
    {
      client.println("error: invalid JSON");
      continue;
    }
    if (!rx["frequency"].is<float>() || !rx["dutyCycle"].is<float>())
    {
      client.println("error: frequency and dutyCycle must be numbers");
      continue;
    }
    float freq = rx["frequency"].as<float>();
    float duty = rx["dutyCycle"].as<float>();
    // Fixed 8-bit resolution; reject unsupported frequencies without a cast overflow.
    if (!isfinite(freq) || !isfinite(duty) || freq < 1 || freq > 100000 ||
        duty < 0 || duty > 100)
    {
      client.println("error: frequency must be 1-100000 Hz; dutyCycle 0-100 percent");
      continue;
    }
    uint32_t requestedHz = static_cast<uint32_t>(lroundf(freq));
    uint32_t actualHz = 0;
    if (!pwmOn)
    {
      pwmOn = ledcAttachChannel(LED_PIN, requestedHz, PWM_BITS, PWM_CHANNEL);
      if (pwmOn) actualHz = ledcReadFreq(LED_PIN);
    }
    else actualHz = ledcChangeFrequency(LED_PIN, requestedHz, PWM_BITS);
    uint32_t ticks = static_cast<uint32_t>(lroundf(duty * PWM_MAX / 100.0f));
    if (!actualHz || !ledcWrite(LED_PIN, ticks))
    {
      client.println("error: PWM configuration failed");
      continue;
    }
    JsonDocument reply;
    reply["type"] = "pwmReply";
    reply["requestedFrequency"] = freq;
    reply["actualFrequency"] = actualHz;
    reply["requestedDutyCycle"] = duty;
    reply["actualDutyCycle"] = ticks * 100.0f / PWM_MAX;
    reply["resolutionBits"] = PWM_BITS;
    serializeJson(reply, client);
    client.println();
  }
}

void loop()
{
  const unsigned long now = millis();
  const int reading = digitalRead(BUTTON_PIN);
  if (reading != lastReading)
  {
    lastReading = reading;
    lastChangeTime = now;
  }
  if (now - lastChangeTime >= DEBOUNCE_MS && reading != stableReading)
  {
    stableReading = reading;
    buttonState = (stableReading == LOW);
    if (buttonState)
    {
      ++buttonPresses;
      buttonPressTime = now;
      updateJSON();
      serializeJson(json, Serial);
      Serial.println();
      if (jsonClient.connected()) sendJSONToClient(jsonClient);
    }
  }

  connectToWiFi(SSID, PASSWORD);
  if (WiFi.status() != WL_CONNECTED)
  {
    if (serversStarted)
    {
      cameraClient.stop();
      jsonClient.stop();
      cameraServer.end();
      jsonServer.end();
      serversStarted = false;
    }
    return;
  }
  if (!serversStarted)
  {
    Serial.print("WiFi connected. ESP32 IP: ");
    Serial.println(WiFi.localIP());
    startCameraServer(CAMERA_PORT);
    startJSONServer(JSON_PORT);
    serversStarted = true;
  }

  // Check if a new camera client connected
  if (!cameraClient.connected()) cameraClient = cameraServer.accept();

  // Check if a new JSON client connected, and send it the current state
  if (!jsonClient.connected())
  {
    jsonClient = jsonServer.accept();
    if (jsonClient)
    {
      incomingLine = "";
      discardLine = false;
      Serial.println("JSON client connected");
      sendJSONToClient(jsonClient);
    }
  }

  // If the JSON client sent us something, handle it
  if (jsonClient.connected() && jsonClient.available())
  {
    handleJSONFromClient(jsonClient);
  }

  // Send an image to the camera client
  if (cameraInitialized && cameraClient.connected()) sendImageToClient(cameraClient);
}
